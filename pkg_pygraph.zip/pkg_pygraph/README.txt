L'idée de ce module pygraph est de créer un objet Graph qui soit la réunion de deux objets :

un model qui est un graphe au sens de networkx
une view qui est un graphe au sens de graphviz
Ajouté à cela un (petit) ensemble de méthodes permettant les opérations usuelles sur les graphes et en essayant de rester simple. L'outil devrait pouvoir aider tout enseignant souhaitant préparer une ressource pédagogique sur le thème des graphes.